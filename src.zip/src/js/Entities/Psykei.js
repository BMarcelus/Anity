class Psykei extends Platformer {
  constructor(x,y) {
    super(x,y,20,80,"#0a0");
  }
  setScene(scene) {
    this.scene=scene;
    scene.specialActors.psykei = this;
  }
  initModel() {
    this.model = new PsykeiModel(this);
  }
}