class GraySpike extends Platformer {
  constructor(x,y) {
    super(x,y,40,80,"#444");
    this.speed = 3;
    this.mx = 1;
    this.maxHealth =
    this.health = 60;
    this.knockBack = 0.1;
    this.isBossin = false;
  }
  setScene(scene) {
    this.scene= scene;
    this.scene.specialActors.darkGraySpike = this;
    this.scene.enemyCount++;
  }
  die() {
    super.die();
    this.scene.enemyCount--;
  }
  initModel() {
    this.model = new DarkGraySpikeModel(this);
  }
  update() {
    super.update();
    if(this.isBossin) {
      this.getInputs = this.getInputs1;
      this.isBossin = false;
    }
  }
  getInputs1() {
    // if(this.grounded&&!this.scene.collides(this.x+this.dx*10,this.y+this.h/2+10)) {
    //   this.mx = -this.mx;
    // }
    if(this.grounded&&this.wallColliding) {
      this.mx = -this.mx;
      this.jump();
    }

    if(frameCount%20==0) {
      this.scene.addEntity(new Sunflower(this.x,this.y));
      SOUNDS.pop.play();
    }

    var player = this.scene.player;
    if(!player)return;
    var dx = player.x-this.x;
    var dy = player.y-this.y;
    var ds = Math.abs(dx)+Math.abs(dy);
    if(ds<100&&this.invul<=0) {
      player.collide(this);
    }
  }
}