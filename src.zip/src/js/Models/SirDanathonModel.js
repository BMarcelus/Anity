class SirDanathonModel extends StickModel {
  constructor(parent) {
    super(40,80,"#0af",parent);
  }
}