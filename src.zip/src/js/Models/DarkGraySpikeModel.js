class DarkGraySpikeModel extends PlatformerModel {
  constructor(parent) {
    super(20,40,"#444", parent);
    this.face.after = [];
    this.body.scaleX = 2;
    this.body.scaleY = 2;
    this.face.drawable = new ImageDrawable(IMAGES.DarkGraySpikeHead, 0,-10, 40);
  }
  faceUpdate() {
    this.face.scaleX = this.parent.dx<0?-1:1;
  }
}