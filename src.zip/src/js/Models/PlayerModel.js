class PlayerModel extends PlatformerModel {
  constructor(parent) {
    super(20,40,"darkgray",parent);
    this.arm1.createAfter(-2,2,new Line(0,0,0,5,"round",5,"black"));
  }
}