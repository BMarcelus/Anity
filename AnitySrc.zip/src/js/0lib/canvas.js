//  Copyright Brian Dizon 2019

var CE = document.getElementById('gc');
var canvas = CE.getContext('2d');
var canvasPercent = "100%";

var SCREEN_CANVASES = [];

function createScreenCanvas() {
  var C = document.createElement('canvas');
  C.width = CE.width;
  C.height = CE.height;
  var ctx = C.getContext('2d');
  SCREEN_CANVASES.push(ctx);
  return {
    CE: C,
    canvas: ctx
  }
}


canvas.fillRectFloor = function(x,y,w,h){
  this.fillRect(Math.floor(x),Math.floor(y),Math.floor(w),Math.floor(h));
}

function onresize(e){
  var rw = window.innerWidth/window.innerHeight;
  var rc = CE.width/CE.height;
  if(rw >= rc) {
    CE.style.height = "100%";
    CE.style.width = "";
  } else {
    CE.style.width = "100%";
    CE.style.height = "";
  }
  
  canvas.imageSmoothingEnabled = false;
  canvas.mozImageSmoothingEnabled=false;
  canvas.msImageSmoothingEnabled = false;
  canvas.oImageSmoothingEnabled=false;
  canvas.webkitImageSmoothingEnabled=false;

  SCREEN_CANVASES.forEach(function(canvas) {
    canvas.imageSmoothingEnabled = false;
    canvas.mozImageSmoothingEnabled=false;
    canvas.msImageSmoothingEnabled = false;
    canvas.oImageSmoothingEnabled=false;
    canvas.webkitImageSmoothingEnabled=false;
  })
}

window.addEventListener('resize', onresize);
window.addEventListener('load', onresize);