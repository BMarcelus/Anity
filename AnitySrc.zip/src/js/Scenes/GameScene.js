
class GameScene extends Scene {
  constructor(level, prev) {
    super();
    if(level) {
      this.addEntity(this.level = level);
    } else {
      this.addEntity(this.level = new Level(LEVELS.getLevelByName("CurleyHallway")));
      this.addEntity(this.level = new Level(World.getNextLevel()));
    }
    this.addEntity(this.player = new Player(100,100));
    // this.addEntity(new Knight(100,-100));
    // this.addEntity(new NPC(2100,0, CurleyModel));
    // this.addEntity(new Curley(2100,0));
    // this.addEntity(new Chomper(2200,0));
    this.camera = {
      x:0,y:0,
      target: this.player,
    };
    this.screenShake = 0;
    this.zoom = 1;
    this.LightMask = createScreenCanvas();
    this.dialogueController = new DialogueController(null,this);
    this.preProcessLevel();
  }
  dialogueProcess(name) {
    var dialogue = GetDialogueData(this,name);
    if(dialogue) {
      this.dialogueController.setSequence(dialogue);
    }
  }
  preProcessLevel() {
    this.enemyCount = 0;
    this.level.preProcess(this);
    this.dialogueProcess(this.level.level.name);
  }
  wallCollideWith(cell,entity) {
    return this.level.wallCollideWith(cell,entity);
  }
  standOn(cell,entity) {
    return this.level.standOn(cell,entity);
  }
  collides(...args) {
    return this.level.collides(...args);
  }
  update() {
    super.update();
    if(DEV&&getButtonDown(Buttons.cheatForward)) {
      this.loadNextLevel();
      this.player.addShoes();
    }
    if(DEV&&getButtonDown(Buttons.cheatBackward)) {
      this.loadPrevLevel();
    }
    if(keys[69]&&DEV) {
      MainDriver.setScene(new LevelEditorScene(this.level,this.player.x,this.player.y));
    }
    var target = this.camera.target;
    var ty = target.y;
    if(!this.dialogueController.done) {
      ty += CE.height/20;
    }
    this.camera.x += Math.floor((target.x-this.camera.x)/10);
    this.camera.y += Math.floor((ty-this.camera.y)/10);
    if(this.camera.x-CE.width/2 < 0) {
      this.camera.x = CE.width/2;
    }
    if(this.camera.y-CE.height/2<0) {
      this.camera.y = CE.height/2;
    }

    if(this.camera.x+CE.width/2 > this.level.width) {
      this.camera.x = this.level.width - CE.width/2;
    }
    if(this.camera.y+CE.height/2> this.level.height) {
      this.camera.y = this.level.height-CE.height/2;
    }

    if(this.player.y>this.level.cellHeight*this.level.rows) {
      this.player.die();
    }
    if(this.screenShake>.001) {
      this.screenShake -= 0.1;
      var r = this.screenShake * 2;
      this.camera.x += Math.cos(frameCount*Math.PI/7)*r;
      this.camera.y += Math.cos(frameCount*Math.PI/13)*r;
      this.camera.rotation = Math.cos(frameCount*19)*Math.PI/200*this.screenShake;
    } else {
      this.camera.rotation = 0;
    }
    if(this.player.x>this.level.width) {
      this.loadNextLevel()
    }
    this.dialogueController.update(); 
  }
  loadLevel(level) {
    this.entities = [];
    this.camera.target = this.player;
    this.player.inputBlocked = false;
    this.addEntity(this.level = new Level(level));
    this.addEntity(this.player);
    this.preProcessLevel();
  }
  loadNextLevel() {
    var nextLevel = World.getNextLevel(this.level);
    this.loadLevel(nextLevel);
  }
  loadPrevLevel() {
    var nextLevel = World.getPrevLevel(this.level);
    this.loadLevel(nextLevel);
  }
  draw() {
    var ctx = this.LightMask.canvas;
    ctx.clearRect(0,0,CE.width,CE.height);
    canvas.save();
      canvas.translate(CE.width/2-this.camera.x,CE.height/2-this.camera.y);
      canvas.rotate(this.camera.rotation);
      super.draw();
    canvas.restore();
    var cx =CE.width/2-this.camera.x;
    var cy =CE.height/2-this.camera.y;
    this.entities.forEach(function(e) {
      if(e.lightDraw) {
        e.lightDraw(ctx,cx,cy);
      }
    })
    // var ambient = "#ffffffaa";    
    var ambient = this.level.tileSet.ambient;
    ctx.fillStyle = ambient;
    ctx.fillRect(0,0,CE.width,CE.height)
    canvas.globalCompositeOperation = "destination-in";
    canvas.drawImage(this.LightMask.CE, 0,0);
    canvas.globalCompositeOperation = "source-over";

    this.dialogueController.draw();
  }
  respawn() {
    this.player.health = this.player.maxHealth;
    this.player.shouldDelete = false;
    this.loadLevel(this.level.level);
    this.camera.target = this.player;
    this.camera.x = this.player.x;
    this.camera.y = this.player.y;
  }
}