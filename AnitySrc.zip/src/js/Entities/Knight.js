class Knight extends Platformer {
  constructor(x,y) {
    super(x,y,20,80,"brown");
    // color = "#0af";
    this.speed = 1;
    this.mx = -1;
    this.jumpStrength = 5;
    this.wallJumps = false;
    this.wallSlide = false;
    this.attackTimer = 0;
  }
  getInputs() {
    if(this.grounded&&!this.scene.collides(this.x+this.dx*10,this.y+this.h/2+10)) {
      this.mx = -this.mx;
    }
    if(this.grounded&&this.wallColliding) {
      this.mx = -this.mx;
    }
    // if(this.wallColliding) {
    //   this.jump();
    // }
    var player = this.scene.player;
    if(!player)return;
    var dx = player.x-this.x;
    var dy = player.y-this.y;
    var ds = Math.abs(dx)+Math.abs(dy);
    if(ds<200) {
      this.attackTimer--
      if(this.attackTimer <=0) {
        this.attack();
        this.attackTimer = 60;
      }
    }
    if(ds<50&&this.invul<=0) {
      if(this.model.attacking) {
        player.getHit(this);
      } else {
        player.collide(this);
      }
    }
  }
  initModel(w,h,color) {
    this.model = new StickModel(w,h,color, this);
  }
}