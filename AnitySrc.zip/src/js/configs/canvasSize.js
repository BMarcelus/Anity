CE.width = 800;
CE.height = 600;